<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <td>
            <form action="<?php echo e(url('alumno/crear')); ?>" method="get">
                <input type="submit" value="Crear alumno">
            </form>
        </td>
        <tr>
            <th>ID</th>
            <th>NOMBRE</th>
            <th>APELLIDO</th>
            <th>EDAD</th>
        </tr>
        
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->nombre_alu); ?></td>
            <td><?php echo e($user->apellido_alu); ?></td>
            <td><?php echo e($user->edad_alu); ?></td>
            <td>
                <form action="<?php echo e(url('alumno/borrar/'.$user->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>


                <?php echo e(method_field('DELETE')); ?>

                <input type="submit" value="Deletear">
                </form>
            </td>
            <td>
                <form action="<?php echo e(url('alumno/modificar/'.$user->id)); ?>" method="get">
                    
                    <input type="submit" value="Modificar">
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/www/PHP/schoolbbdd/resources/views/mostrarvista.blade.php ENDPATH**/ ?>