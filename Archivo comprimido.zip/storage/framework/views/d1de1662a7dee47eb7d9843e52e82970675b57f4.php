<!DOCTYPE HTML>
<html>
<head>
  <title>Login alumno</title>
  <meta charset="UTF-8">
</head>
<body>
  <form action="<?php echo e(url('alumno/login_post')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <?php echo e(method_field('PUT')); ?>

      Correo admin
      <input type="text" name="correo" placeholder="Correo...">
      <br>
      Contraseña admin
      <input type="password" name="password" placeholder="Apellido...">
      <br>
      <input type="submit" value="Loginar">
  </form>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/www/PHP/schoolbbdd/resources/views/login.blade.php ENDPATH**/ ?>