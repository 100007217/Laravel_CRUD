<!DOCTYPE HTML>
<html>
<head>
  <title>Crear alumno</title>
  <meta charset="UTF-8">
</head>
<body>
  <form action="<?php echo e(url('alumno/crear_alu')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <?php echo e(method_field('PUT')); ?>

      Nombre alumno
      <input type="text" name="nombre_alu" placeholder="Nombre...">
      <br>
      Apellido alumno
      <input type="text" name="apellido_alu" placeholder="Apellido...">
      <br>
      Edad alumno
      <input type="text" name="edad_alu" placeholder="Edad...">
      <br>
      <input type="submit" value="Crear">
  </form>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/www/PHP/schoolbbdd/resources/views/form_crear.blade.php ENDPATH**/ ?>